#pragma once

typedef enum {
	StrID_NONE, 
	StrID_Name,
	StrID_Description,
	StrID_Err_LoadSuite,
	StrID_Err_FreeSuite,
	StrID_NUMTYPES
} StrIDType;
